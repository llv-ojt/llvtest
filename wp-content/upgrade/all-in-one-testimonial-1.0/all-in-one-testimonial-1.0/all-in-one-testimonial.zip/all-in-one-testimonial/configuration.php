<?php

// for the first time configuration
if(get_option('teffect') == '')
add_option('teffect','fade');

if(get_option('tspeed1') == '')
add_option('tspeed1','1000');

if(get_option('ttimeout') == '')
add_option('ttimeout','3000');

if(get_option('teasing1') == '')
add_option('teasing1','easeInQuad');

if(get_option('tshow_nav') == '')
add_option('tshow_nav','Yes');

if(get_option('tshow_nav_pos') == '')
add_option('tshow_nav_pos','Top');

if(get_option('tshow_next_prev') == '')
add_option('tshow_next_prev','Yes');

if(get_option('tshow_next_prev_pos') == '')
add_option('tshow_next_prev_pos','Top');

if(get_option('tslide_order') == '')
add_option('tslide_order','ASC');

if(get_option('words_count') == '')
add_option('words_count','15');

if(get_option('thumb_height') == '')
add_option('thumb_height','80');

if(get_option('thumb_width') == '')
add_option('thumb_width','80');

if(get_option('testi_background') == '')
add_option('testi_background','#282828');

if(get_option('testi_font_color') == '')
add_option('testi_font_color','#CCCCCC');

// after submit
if($_POST['submit']!='')
{
$teffect = $_POST['teffect'];
delete_option('teffect');
add_option('teffect',$teffect);

$tspeed1 = $_POST['tspeed'];
delete_option('tspeed1');
add_option('tspeed1',$tspeed1);

$ttimeout = $_POST['ttimeout'];
delete_option('ttimeout');
add_option('ttimeout',$ttimeout);

$teasing1 = $_POST['teasing'];
delete_option('teasing1');
add_option('teasing1',$teasing1);

$thumb_height = $_POST['thumb_height'];
delete_option('thumb_height');
add_option('thumb_height',$thumb_height);

$thumb_width = $_POST['thumb_width'];
delete_option('thumb_width');
add_option('thumb_width',$thumb_width);

$tshow_nav = $_POST['tshow_nav'];
delete_option('tshow_nav');
add_option('tshow_nav',$tshow_nav);

$tshow_nav_pos = $_POST['tshow_nav_pos'];
delete_option('tshow_nav_pos');
add_option('tshow_nav_pos',$tshow_nav_pos);

$tshow_next_prev = $_POST['tshow_next_prev'];
delete_option('tshow_next_prev');
add_option('tshow_next_prev',$tshow_next_prev);

$tshow_next_prev_pos = $_POST['tshow_next_prev_pos'];
delete_option('tshow_next_prev_pos');
add_option('tshow_next_prev_pos',$tshow_next_prev_pos);

$tslide_order = $_POST['tslide_order'];
delete_option('tslide_order');
add_option('tslide_order',$tslide_order);

$words_count = $_POST['words_count'];
delete_option('words_count');
add_option('words_count',$words_count);

$testi_background = $_POST['testi_background'];
delete_option('testi_background');
add_option('testi_background',$testi_background);

$testi_font_color = $_POST['testi_font_color'];
delete_option('testi_font_color');
add_option('testi_font_color',$testi_font_color);
}
?>
<h1>All in One Testimonial</h1>
<form method="post" action="#" id="configform">
<table id="configtable">
<tr>
<td>
    <table>
    <tr>
    <td colspan="2">
    <h3>Slider Configuration</h3>
    </td>
    </tr>
    <tr>
    <td>
    Transition Effect: 
    </td>
    <td>
    <select name="teffect">
    <option value="<?php echo get_option('teffect'); ?>" selected="selected"><?php echo get_option('teffect'); ?></option>
    <option value="blindX">blindX</option>
    <option value="blindY">blindY</option>
    <option value="blindZ">blindZ</option>
    <option value="cover">cover</option>
    <option value="curtainX">curtainX</option>
    <option value="curtainY">curtainY</option>
    <option value="fade">fade</option>
    <option value="fadeZoom">fadeZoom</option>
    <option value="growX">growX</option>
    <option value="growY">growY</option>
    <option value="scrollUp">scrollUp</option>
    <option value="scrollDown">scrollDown</option>
    <option value="scrollLeft">scrollLeft</option>
    <option value="scrollRight">scrollRight</option>
    <option value="scrollHorz">scrollHorz</option>
    <option value="scrollVert">scrollVert</option>
    <option value="shuffle">shuffle</option>
    <option value="slideX">slideX</option>
    <option value="slideY">slideY</option>
    <option value="toss">toss</option>
    <option value="turnUp">turnUp</option>
    <option value="turnDown">turnDown</option>
    <option value="turnLeft">turnLeft</option>
    <option value="turnRight">turnRight</option>
    <option value="uncover">uncover</option>
    <option value="wipe">wipe</option>
    <option value="zoom">zoom</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <td>
    Speed: 
    </td>
    <td>
    <input type="text" name="tspeed" value="<?php echo get_option('tspeed1'); ?>" />
    </td>
    </tr>
    
    <tr>
    <td>
    Timeout: 
    </td>
    <td>
    <input type="text" name="ttimeout" value="<?php echo get_option('ttimeout'); ?>" />
    </td>
    </tr>
    
    <tr>
    <td>
    Easing: 
    </td>
    <td>
    <select name="teasing">
      <option value="<?php echo get_option('teasing1'); ?>" selected="selected"><?php echo get_option('teasing1'); ?></option>
      <option value="jswing">jswing</option>
      <option value="def">def</option>
      <option value="easeInQuad">easeInQuad</option>
      <option value="easeOutQuad">easeOutQuad</option>
      <option value="easeInOutQuad">easeInOutQuad</option>
      <option value="easeInCubic">easeInCubic</option>
      <option value="easeOutCubic">easeOutCubic</option>
      <option value="easeInOutCubic">easeInOutCubic</option>
      <option value="easeInQuart">easeInQuart</option>
      <option value="easeOutQuart">easeOutQuart</option>
      <option value="easeInOutQuart">easeInOutQuart</option>
      <option value="easeInQuint">easeInQuint</option>
      <option value="easeOutQuint">easeOutQuint</option>
      <option value="easeInOutQuint">easeInOutQuint</option>
      <option value="easeInSine">easeInSine</option>
      <option value="easeOutSine">easeOutSine</option>
      <option value="easeInOutSine">easeInOutSine</option>
      <option value="easeInExpo">easeInExpo</option>
      <option value="easeOutExpo">easeOutExpo</option>
      <option value="easeInOutExpo">easeInOutExpo</option>
      <option value="easeInCirc">easeInCirc</option>
      <option value="easeOutCirc">easeOutCirc</option>
      <option value="easeInOutCirc">easeInOutCirc</option>
      <option value="easeInElastic">easeInElastic</option>
      <option value="easeOutElastic">easeOutElastic</option>
      <option value="easeInOutElastic">easeInOutElastic</option>
      <option value="easeInBack">easeInBack</option>
      <option value="easeOutBack">easeOutBack</option>
      <option value="easeInOutBack">easeInOutBack</option>
      <option value="easeInBounce">easeInBounce</option>
      <option value="easeOutBounce">easeOutBounce</option>
      <option value="easeInOutBounce">easeInOutBounce</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <td>
    Show Navigation Button:
    </td>
    
    <td>
    <select name="tshow_nav">
    <?php $t_nav = get_option('tshow_nav'); ?>
    <option <?php if($t_nav=='Yes') echo "selected='selected'"; ?> value="Yes">Yes</option>
    <option <?php if($t_nav=='No') echo "selected='selected'"; ?> value="No">No</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <td>
    Show Next/Prev Button:
    </td>
    
    <td>
    <?php $t_next_prev = get_option('tshow_next_prev'); ?>
    <select name="tshow_next_prev">
    <option <?php if($t_next_prev=='Yes') echo "selected='selected'"; ?> value="Yes">Yes</option>
    <option <?php if($t_next_prev=='No') echo "selected='selected'"; ?> value="No">No</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <td>
    Next/Prev Button Position:
    </td>
    
    <td>
    <select name="tshow_next_prev_pos">
    <?php $t_next_prev_pos = get_option('tshow_next_prev_pos'); ?>
    <option <?php if($t_next_prev_pos=='Top') echo "selected='selected'"; ?> value="Top">Top</option>
    <option <?php if($t_next_prev_pos=='Bottom') echo "selected='selected'"; ?> value="Bottom">Bottom</option>
    </select>
    </td>
    </tr>
    
    <tr>
    <td>
    Slide Order:
    </td>
    <td>
    <?php $t_order = get_option('tslide_order'); ?>
    <select name="tslide_order">
    <option <?php if($t_order=='ASC') echo "selected='selected'"; ?> value="ASC">ASC</option>
    <option <?php if($t_order=='DESC') echo "selected='selected'"; ?> value="DESC">DESC</option>
    </select>
    </td>
    </tr>

<!--     
    <tr>
    <td>
	Words Count:
    </td>
    <td>
	<input type="text" name="words_count" value="<?php // echo get_option('words_count'); ?>" />
    </td>
    </tr>
--> 
    
    </table>
</td>
<td>
        <table>
        <tr>
        <td colspan="2">
        <h3>Thumbnail Configuration</h3>
        </td>
        </tr>
        
        <tr>
        <td>
        Thumbnail Height:
        </td>
        
        <td>
        <input type="text" name="thumb_height" value="<?php echo get_option('thumb_height'); ?>" />
        </td>
        </tr>
        
        <tr>
        <td>
        Thumbnail Width:
        </td>
        
        <td>
        <input type="text" name="thumb_width" value="<?php echo get_option('thumb_width'); ?>" />
        </td>
        </tr>
        
        <tr>
        <td colspan="2">
        <h3>Color Code</h3>
        </td>
        </tr>
        
        <tr>
        <td>
        Background Color:
        </td>
        <td>
        <input type="text" name="testi_background" class="color-picker" size="6" autocomplete="on" maxlength="10" value="<?php echo get_option('testi_background'); ?>" />
        </td>
        </tr>
        
        <tr>
        <td>
        Font Color:
        </td>
        <td>
        <input type="text" name="testi_font_color" class="color-picker" size="6" autocomplete="on" maxlength="10" value="<?php echo get_option('testi_font_color'); ?>" />
        </td>
        </tr>
        
        <tr>
        <td colspan="2">
        <input type="submit" id="formsubmit" value="Submit" name="submit" class="button-primary"/>
        </td>
        </tr>
        </table>
</td>
</tr>
</table>
        
</form>