<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>All in One Testimonial</title>
<script type="text/javascript">
function validation(){
	var quote = tinyMCE.get('quote').getContent();
	var regex = /(<([^>]+)>)/ig;
	var quote = quote.replace(regex, "");
	
 	var author = document.getElementById('author').value;
	if((quote == '') && (author == '')){
		alert("Enter Quote & Author's Name");
		return false;
	}
	else if(quote == ''){
		alert("Enter Quote for the Testimonial");
		return false;
	}
	else if(author == ''){
		alert("Enter Author's Name");
		return false;
	}
}
</script>
</head>
<?php
//----------------------Functions-------------------------

function entry_form_testimonial($qry_row)
{ 
?>
<div class="alert">All Fields are not mandatory, so you can fill the details which you want to show on front side.</div><br/>
		<form action="?page=Testimonial" method="post" enctype="multipart/form-data" class="addform"  onsubmit="return validation()" >
    	<table class="addformtable">
        	<tr>
            	<td>Quote: <span class="alert">*</span></td>
                <td>
                <?php 
					$textareacontent =  $qry_row["quote"]; 
					the_editor($textareacontent, $id = 'quote', $prev_id = 'quote', $media_buttons = false, $tab_index = 2, $extended = true);
				?>
                </td>
            </tr>
            </td>
            <tr>    
               	<td>Author's Name: <span class="alert">*</span></td>
                <td><input type="text" name='author' id='author' value='<?php echo $qry_row["author"]; ?>' /></td>
            </tr>
            <tr>
                <td>Designation: </td>
                <td><input type="text" name='designation' id='designation' value='<?php echo $qry_row["designation"]; ?>' /></td>
             </tr>
             <tr>
                <td>Company Name: </td>
                <td><input type="text" name='company' id='company' value='<?php echo $qry_row["company"]; ?>' /></td>
             </tr>
             <tr>
                <td>Company URL: </td>
                <td><input type="text" name='company_url' id='company_url' value='<?php echo $qry_row["company_url"]; ?>' /> (add the URL starting from http://)</td>
             </tr>
             <tr>
			 <tr>
                <td>Category: </td>
                <td>
				<?php
					global $wpdb;
					$qry_cat="select * from ".$wpdb->prefix."testimonial_category";
					$result_cat=mysql_query($qry_cat);
				?>
                <select name="cat_id">
					<?php
					while($row=mysql_fetch_array($result_cat))
					{ 
 					?>
                	<option <?php if($qry_row["cat_id"]==$row['id']) echo "selected='selected'"; ?>  value="<?php echo $row['id']; ?>"><?php echo $row['cat_name']; ?></option>          
					<?php } ?>         
                </select>
                </td>
             </tr>
             <tr>
                <td>Rating: </td>
                <td>
                <select name="rating">
                   	<option <?php if($qry_row["rating"]=='Select') echo "selected='selected'"; ?>  value="Select">Select</option>
                	<option <?php if($qry_row["rating"]=='5') echo "selected='selected'"; ?>  value="5">5</option>
                    <option <?php if($qry_row["rating"]=='4') echo "selected='selected'"; ?> value="4">4</option>
                    <option <?php if($qry_row["rating"]=='3') echo "selected='selected'"; ?> value="3">3</option>
                    <option <?php if($qry_row["rating"]=='2') echo "selected='selected'"; ?> value="2">2</option>
                    <option <?php if($qry_row["rating"]=='1') echo "selected='selected'"; ?> value="1">1</option>
                </select>
                </td>
             </tr>
                <td>Upload Author's Thumbnail: </td>
                <td><input type="file" name='img1' id='img1' />
                	<input type="hidden" name='id' value='<?php echo $qry_row["id"]; ?>' />
                </td>
            </tr>
            <tr>
                <td><input type="submit" name='send' value="Send" id='send' class="button-primary" /></td>
            </tr>
        </table>
    </form>	
<?php 
}

function display_testimonial()
{
	global $wpdb;
	$qry="select * from ".$wpdb->prefix."testimonial";
	$result=mysql_query($qry);
	?> 
	<table id="ext_db_table" class="widefat" border="_peopleprofiletype">
				<thead>
					<tr>
						<th scope="col" width="10%">Image</th>
						<th scope="col" width="30%">Quote</th>
						<th scope="col" width="20%">Author</th>
						<th scope="col" width="20%">Category</th>
						<th scope="col" width="5%">Edit</th>
						<th scope="col" width="5%">Delete</th>
					</tr>
				</thead>
		
	<?php 
	while($row=mysql_fetch_array($result))
	{ ?> 
		<tr>
			<td>
				<img src='../wp-content/plugins/testimonial/upload/<?php echo $row['image']; ?>' height="50px" width="50px" />
			</td>
		
			<td>
				<?php echo $row['quote']; ?>
			</td>
		   
			<td>
				<?php echo $row['author']; ?>
			</td>
		   
		   	<td>
				<?php 
					global $wpdb;
					$qry_cat="select * from ".$wpdb->prefix."testimonial_category where id=".$row['cat_id'];
					$result_cat=mysql_query($qry_cat);
					while($row_cat = mysql_fetch_array($result_cat))
					{						
							echo $row_cat['cat_name'];
					}
				?>
			</td>
		   
			<td>
				<a href="?page=Testimonial&action=edit&id=<?php echo $row['id']; ?>">Edit</a>
			</td>
			<td>
				<a href="?page=Testimonial&action=delete&id=<?php echo $row['id']; ?>">Delete</a>
			</td>
		</tr>
	<?php  
	} // while end 
	?> 
	</table>
<?php
} // function display end

function add_testimonial_data($data)
{
	global $wpdb;
	$cat_id = $_REQUEST['cat_id'];
	$quote=$_REQUEST['quote'];
	$author=$_REQUEST['author'];
 	$designation=$_REQUEST['designation'];
 	$company=$_REQUEST['company'];
	$img1= $_FILES['img1']['name'];
	$qry_add="INSERT INTO ".$wpdb->prefix."testimonial (cat_id,quote,author,designation,company,company_url,rating,image) values ('".$cat_id."','".$quote."','".$author."','".$designation."','".$company."','".$company_url."','".$rating."','".$img1."')";
	mysql_query($qry_add);
	move_uploaded_file($_FILES["img1"]["tmp_name"], "../wp-content/plugins/testimonial/upload/" . $_FILES["img1"]["name"]);
	display_testimonial();
}

function update_testimonial_data($data)
{
	global $wpdb;
	$file_name=$_FILES["img1"]["name"];

	if($file_name == '')
	{
 		$qry_update="UPDATE ".$wpdb->prefix."testimonial set cat_id='$data[cat_id]', quote='$data[quote]', author='$data[author]', designation='$data[designation]', company='$data[company]', company_url='$data[company_url]', rating='$data[rating]' where id=".$data['id'];
	}
	else
	{
		$qry_update="UPDATE ".$wpdb->prefix."testimonial set cat_id='$data[cat_id]', quote='$data[quote]', author='$data[author]',designation='$data[designation]', company='$data[company]', company_url='$data[company_url]', rating='$data[rating]', image='$file_name' where id=".$data['id'];
	}
	mysql_query($qry_update);
	move_uploaded_file($_FILES["img1"]["tmp_name"], "../wp-content/plugins/testimonial/upload/" . $_FILES["img1"]["name"]);
	display_testimonial();
}

function delete_testimonial_data($del_id)
{
	global $wpdb;
	$qry_delete='DELETE from '.$wpdb->prefix.'testimonial where id='.$del_id;
	mysql_query($qry_delete);
	display_testimonial();
}

// ----------------To add/edit & delete category---------------

function entry_form_testimonial_cat($qry_row)
{ 
?>
	<form action="?page=categories" method="post">
		<table class="addformtable">
			<tr>
				<td>
					Category Name : 
				</td>
				<td>
					<input type="text" name="cat_name" id="cat_name" value='<?php echo $qry_row["cat_name"]; ?>' />
				</td>				
			</tr>
			
			<tr>
				<td>
					<input type="submit" name="submit" id="submit" class="button-primary" value="submit" />
					<input type="hidden" name='id' value='<?php echo $qry_row["id"]; ?>' />
				</td>
			</tr>
		</table>

    </form>	
<?php 
}

function display_testimonial_cat()
{
	global $wpdb;
	$qry="select * from ".$wpdb->prefix."testimonial_category";
	$result=mysql_query($qry);
	?> 
	<table id="ext_db_table" class="widefat" border="_peopleprofiletype">
				<thead>
					<tr>
						<th scope="col" width="60%">Category Name</th>	
						<th scope="col" width="10%">Edit</th>
						<th scope="col" width="10%">Delete</th>					
					</tr>
				</thead>
		
	<?php 
	while($row=mysql_fetch_array($result))
	{ ?> 
		<tr>
			<td>
				<?php echo $row['cat_name']; ?>
			</td>
			<td>
				<a href="?page=categories&action=edit_cat&id=<?php echo $row['id']; ?>">Edit</a>
			</td>
			<td>
				<a href="?page=categories&action=delete_cat&id=<?php echo $row['id']; ?>">Delete</a>
			</td>
		</tr>
	<?php  
	} // while end 
	?> 
	</table>
<?php
} // function display end

function add_testimonial_cat($data)
{
	$cat_name=$_REQUEST['cat_name'];
	global $wpdb;
    $qry_add="INSERT INTO ".$wpdb->prefix."testimonial_category (cat_name) values ('".$cat_name."')";
	mysql_query($qry_add);
	display_testimonial_cat();
}

function update_testimonial_cat($data)
{
		global $wpdb;
  		$qry_update="UPDATE ".$wpdb->prefix."testimonial_category set cat_name='$data[cat_name]' where id=".$data['id'];

	mysql_query($qry_update);	
	display_testimonial_cat();
}

function delete_testimonial_cat($del_id)
{
	global $wpdb;
	$qry_delete='DELETE from '.$wpdb->prefix.'testimonial_category where id='.$del_id;
	mysql_query($qry_delete);
	display_testimonial_cat();
}


// ---------------- For the star rating -----------------------
function star_rating($rate)
{
	$plugin_url = plugins_url();
	if($rate == '5')
	echo "<img src='".$plugin_url."/testimonial/images/5star.png' height='17px' width='75px' /> ";
	if($rate == '4')
	echo "<img src='".$plugin_url."/testimonial/images/4star.png' height='17px' width='75px' /> ";
	if($rate == '3')
	echo "<img src='".$plugin_url."/testimonial/images/3star.png' height='17px' width='75px' /> ";
	if($rate == '2')
	echo "<img src='".$plugin_url."/testimonial/images/2star.png' height='17px' width='75px' /> ";
	if($rate == '1')
	echo "<img src='".$plugin_url."/testimonial/images/1star.png' height='17px' width='75px' /> ";
}
?>