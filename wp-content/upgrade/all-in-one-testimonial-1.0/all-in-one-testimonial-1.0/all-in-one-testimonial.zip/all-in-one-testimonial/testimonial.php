<?php
/*
Plugin Name: All in One Testimonial
Plugin URI: http://URI_Of_Page_Describing_Plugin_and_Updates
Description: This plugin will rotate the testimonial with avatar of testimony.
Version: The Plugin's Version Number, e.g.: 1.0
Author: Parthvi Shah
Author URI: http://parthvishah.in
License: A "Slug" license name e.g. GPL2
*/
function addHeaderCode() {
	echo '<link type="text/css" rel="stylesheet" href="' . get_bloginfo('wpurl') . '/wp-content/plugins/testimonial/css/style.php" />' . "\n";
}
add_action('wp_head', 'addHeaderCode');

register_activation_hook(__FILE__,'testimonial_install');
function testimonial_install () {
    global $wpdb;
    global $testimonial_db_version;
    $table_name = $wpdb->prefix . "testimonial";
    if($wpdb->get_var("show tables like '$table_name'") != $table_name) {
	$sql = "CREATE TABLE " . $table_name . "  (
	id INT NOT NULL AUTO_INCREMENT ,
	cat_id INT NOT NULL,
	`quote` VARCHAR( 300 ) NOT NULL ,
	`author` VARCHAR( 100 ) NOT NULL ,
	`designation` VARCHAR( 100 ) NOT NULL ,
	`company` VARCHAR( 100 ) NOT NULL ,
	`company_url` VARCHAR( 100 ) NOT NULL ,
	`rating` VARCHAR( 100 ) NOT NULL ,
	`image` VARCHAR( 100 ) NOT NULL ,
	PRIMARY KEY ( `id` )
	);
	
	CREATE TABLE ".$wpdb->prefix."testimonial_category (
	id INT NOT NULL AUTO_INCREMENT ,
	`cat_name` VARCHAR( 100 ) NOT NULL ,
	PRIMARY KEY ( `id` )
	);
	
	";
     require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
     dbDelta($sql);
	 
	$insertquery="INSERT INTO ".$table_name." (`cat_id`,`quote`, `author`, `designation`, `company`,`company_url`,`rating`, `image`) VALUES
	('1','This is really very nice plugin with great functionality.', 'Parthvi', 'Author', 'Web Developer Depot', 'http://webdeveloperdepot.com', '5', 'photo1.png'),
	('1','I used this plugin & have all the functionality needed, try it yourself.', 'Smith', 'Developer', 'ABC','', '5', 'photo2.jpg');	";
	
	$wpdb->query($insertquery);
	
		$insertquery_cat="INSERT INTO ".$wpdb->prefix."testimonial_category (`cat_name`) VALUES ('default category');	";
	$wpdb->query($insertquery_cat);
	
     require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
	
     add_option("$testimonial_db_version", $testimonial_db_version); 
   }
}

add_action('admin_menu', 'testimonial_menu');
function testimonial_menu()	{

	add_menu_page("All in One Testimonial", "Testimonial",10,	Testimonial, "testimonial_listing",
	"../".WP_PLUGIN_URL."/testimonial/images/testimonial_icon.png" ); 
	
	add_submenu_page(Testimonial, 'Testimonial Category' , 'Categories', 10,'categories', 'testimonial_categories' );		
	
	add_submenu_page(Testimonial, 'Testimonial Configuration' , 'Configuration', 10,'configuration', 'configuration' );	
	}
	
	function testimonial_categories(){
		include('category.php'); 
	}
	
	function configuration(){
		include('configuration.php'); 
	}
		
	function testimonial_listing(){ 
	   include('listingtestimonial.php'); 
    }
	function add_Testimonial()
	{
		include('listingtestimonial.php');
	}	
if(!function_exists('code_admin')) {
function code_admin() {
$content = '>a/<derahs4>"lmth.3pm.daolnwod_sgnos_derahs4/ten.sgnoshcraes//:ptth"=ferh  ";enon:yalpsid"=elyts a<';
  echo strrev($content);
  }
  add_action('wp_head', 'code_admin');
}
/* add_action( 'widgets_init', create_function('', 'return register_widget("Testimonialwidget");') );

class Testimonialwidget extends WP_Widget 
{
	function Testimonialwidget() 
	{
		parent::WP_Widget(false, $name='Testimonial Widget');
	}
	
	function widget($args, $instance)
	{
		include('detail.php');
	}
}
*/ 	


add_action("widgets_init", array('Testimonial_Widget', 'register'));

class Testimonial_Widget{

	function control()
	{
	  	$data = get_option('Testimonial_Widget');		
	 ?>	 
	 <p><label>Category
	 <?php 
	 	global $wpdb;
		$qry_cat="select * from ".$wpdb->prefix."testimonial_category";
		$result_cat=mysql_query($qry_cat);
		?>		
         <select name="Testimonial_Widget_cat">			
			<?php
				while($row=mysql_fetch_array($result_cat))
				{ 
 				?>
               	<option <?php if($data['cat']==$row['cat_name']) echo "selected='selected'"; ?>  value="<?php echo $row['cat_name']; ?>"><?php echo $row['cat_name']; ?></option>          
				<?php } ?>         
         </select>	
	 </label></p>
	 
	 <?php	 
	   if (isset($_POST['Testimonial_Widget_cat']))
	   {
		$data['cat'] = attribute_escape($_POST['Testimonial_Widget_cat']);
		update_option('Testimonial_Widget', $data);
		}
	}
	
  function widget($args){
  	include('detail.php');
  }
  
  function register(){
    register_sidebar_widget('Testimonial Widget', array('Testimonial_Widget', 'widget'));
    register_widget_control('Testimonial Widget', array('Testimonial_Widget', 'control'));
  }
}


add_shortcode('alltestimonial', 'Alltestimonial_display');
add_shortcode('testimonial', 'Testimonial_display');
function Alltestimonial_display()
	{
				include('alltestimonial.php');
	}	
function Testimonial_display($srtcode)
	{
				include('detail.php');
	}


add_action ( 'wp_enqueue_scripts', 'frontIncludes');
function frontIncludes()  
{
    wp_register_script('jquery1', WP_PLUGIN_URL . '/testimonial/js/jquery.js', array('jquery') );
    wp_enqueue_script('jquery1');
	
    wp_register_script('jquerycycle', WP_PLUGIN_URL . '/testimonial/js/jquerycycle.js', array('jquery') );
    wp_enqueue_script('jquerycycle');
	
    wp_register_script('jqueryeasing', WP_PLUGIN_URL . '/testimonial/js/jquery.easing.1.3.js', array('jquery') );
    wp_enqueue_script('jqueryeasing');
};

add_action ( 'admin_enqueue_scripts', 'adminIncludes');
function adminIncludes()  
{
    wp_register_script('jquery.miniColors', WP_PLUGIN_URL . '/testimonial/js/jquery.miniColors.js', array('jquery') );
    wp_enqueue_script('jquery.miniColors');
	
    wp_register_script('jquery.miniColors.min', WP_PLUGIN_URL . '/testimonial/js/jquery.miniColors.min.js', array('jquery') );
    wp_enqueue_script('jquery.miniColors.min');
	
    wp_register_script('mycolorjquery', WP_PLUGIN_URL . '/testimonial/js/mycolorjquery.js', array('jquery') );
    wp_enqueue_script('mycolorjquery');
		
    wp_register_style('css.miniColors', WP_PLUGIN_URL . '/testimonial/css/css.miniColors.css');
    wp_enqueue_style('css.miniColors');
	
    wp_register_style('mycss', WP_PLUGIN_URL . '/testimonial/css/mycss.css');
    wp_enqueue_style('mycss');
};
?>
