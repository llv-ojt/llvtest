<?php 
    header("Content-type: text/css; charset: UTF-8");
	include('../../../../wp-config.php');
	global $wpdb;
	$table_prefix = $wpdb->prefix;
?>

#testimonial_widget
{
	width:100%;
	overflow:hidden;
    background:<?php echo get_option('testi_background'); ?>;
    color:<?php echo get_option('testi_font_color'); ?>
}

#main_header{
overflow:hidden;
padding:5px;
border:1px solid #CCC;
}

#headerpart img{
	float:left;
}

#headerpart #testiheader{
    color: #3D87C4;
    font-size: 20px;
    line-height: 25px;
    float:left;
}

#navigation_button{
float:right;
}

.slideshow_testimonial
{
	font-family:verdana;
    font-size:12px;
	float:left;
	width:100%;
	overflow:hidden;
}

#main_bottom{
  	overflow:hidden;
    padding:5px;
    border-left: 1px solid #CCC;
    border-right: 1px solid #CCC;
    border-bottom: 1px solid #CCC;
    border-top: 1px solid #FFF;
}

<?php 
$t_next = get_option('tshow_next_prev');
if($t_next == 'No'){
?>
#next_testimonial, #prev_testimonial{display:none;}
<?php } ?>

#next_testimonial
{
	background:url(../images/arrow_next.png) no-repeat scroll 0% 0%;
	float:left;
	width:20px;
	height:20px;
	margin-right:1px;
}
#prev_testimonial
{
	background:url(../images/arrow_prev.png) no-repeat scroll 0% 0%;
	float:left;
	width:20px;
	height:20px;
	margin-left:1px;
}
.slideshow_testimonial #testi
{
	width:100% !important; 
	float:left; 
	overflow:hidden;
}

/* for the preload of images */
.slideshow_testimonial .firsttesti{
display:block
}

#testi_content{
    float: left;
    overflow: hidden;
    width: 100%;
}

#testi_quote
{	
	padding-top:6px;
	display:block;
    overflow:hidden;
    font-style:italic;
}
#testi_img
{
	 float:left;
	 margin:0px 5px 4px 0px;
	 height:<?php echo get_option('thumb_height')."px"; ?>;
	 width:<?php echo get_option('thumb_width')."px"; ?>;
}
#author_info
{
	width:100%;
	float:left;
	padding-top:15px;
    padding-left:10px;
    overflow:hidden;
}

#thumb_rating{
	float:left;
    width:<?php echo get_option('thumb_width')."px"; ?>;
}

#rating_display{
	float:left;
    margin-left:10px;
}

#authors_detail{
	overflow:hidden;
    float:left;
    margin-left:10px;
}

#testi_author{
line-height:16px;
color:#FFF;
}

#author_detail{
float:leftl
}

#author_info img{
	margin:right:5px;
    border:2px solid #FFF;
}

#author_info a{
color:<?php echo get_option('testi_font_color'); ?>;
}

#quote_open
{
	float:left;
	margin-right:3px;
}
#quote_close
{
	float:right;
    margin-top:-15px;
    margin-left:6px;
}


/*-----------------------------------Page or Post dispaly css--------------------- */

#testimonial_display{
	overflow:hidden;
    border-bottom:1px solid #CCC;
    padding-top:5px;
}

#testimonial_display td
{
	vertical-align:top;
}

#testi_nav{
<?php 
$t_nav = get_option('tshow_nav'); 
if($t_nav == 'No')
echo "display:none";
else
echo "height:30px; float:right";
?>
}

#testi_nav a{
    background: url("../images/nav_bg.png") no-repeat scroll 0 0 transparent;
    margin-right: 2px;
	color:#AAA9A8;
	padding:3px 7px 5px;
    font-weight:bold;
}

#testi_nav a.activeSlide{
    background: url("../images/nav_bg.png") no-repeat scroll 0 0 transparent;
	color:#3D87C4;
}

#testimonial_display #athumb{
	float:left;
    width:<?php echo get_option('thumb_width')."px"; ?>;
    margin-right:5px;
}

#testimonial_display #athumb img{
   width:<?php echo get_option('thumb_width')."px"; ?>;
   height:<?php echo get_option('thumb_height')."px"; ?>;
}