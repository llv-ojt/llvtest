<h1>All in One Testimonial</h1>
<a href='?page=Testimonial&action=add' id="addentry" ><input class="button-primary" type="button"  value="Add Entry"></a> <br/><br/>

<?php 
//-------------------Connection -----------------------------
	global $wpdb; 
	include_once('myfunction.php');
?>

<?php 

//-----------------After form subbmission---------------------------

if($_REQUEST['send'] == 'Send' )
{
 	if($_REQUEST['id'] == '')
	add_testimonial_data($_REQUEST);


	elseif($_REQUEST['id'] != '' )
	update_testimonial_data($_REQUEST);
}


//--------------------For Main screen---------------------------------
if(($_REQUEST['action'] == '') && (!isset($_REQUEST['send'])) )
{ 
	display_testimonial();
}

//-------------------For Add---------------------------------------
if($_REQUEST['action'] == 'add')
{
	$blank_data = '';
	entry_form_testimonial($blank_data);
}

//-------------------For Edit-------------------------------------
if($_REQUEST['action'] == 'edit')
{ 
	global $wpdb;
	
	$id=$_REQUEST['id'];
	$qry_value='select * from '.$wpdb->prefix.'testimonial where id='.$id;
	$qry_result1=mysql_query($qry_value);
	while($qry_row=mysql_fetch_array($qry_result1))
	{ //while loop for edit
		entry_form_testimonial($qry_row);
	}
}

//--------------for delete ---------------------------
if($_REQUEST['action'] == 'delete')
{
	$del_id=$_REQUEST['id'];
	delete_testimonial_data($del_id);
}

?>
</html>