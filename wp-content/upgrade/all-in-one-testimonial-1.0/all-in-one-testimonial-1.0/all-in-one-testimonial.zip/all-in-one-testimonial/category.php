<h1>All in One Testimonial</h1>
<a href='?page=categories&action=add_cat' id="addentry" ><input class="button-primary" type="button"  value="Add Entry"></a> <br/><br/>

<?php 
//-------------------Connection -----------------------------
	global $wpdb; 
	include_once('myfunction.php');
?>

<?php 

//-----------------After form subbmission---------------------------

if($_REQUEST['submit'] == 'submit' )
{
 	if($_REQUEST['id'] == '')
	add_testimonial_cat($_REQUEST);


	elseif($_REQUEST['id'] != '' )
	update_testimonial_cat($_REQUEST);
}


//--------------------For Main screen---------------------------------
if(($_REQUEST['action'] == '') && (!isset($_REQUEST['submit'])) )
{ 
	display_testimonial_cat();
}

//-------------------For Add---------------------------------------
if($_REQUEST['action'] == 'add_cat')
{
	$blank_data = '';
	entry_form_testimonial_cat($blank_data);
}

//-------------------For Edit-------------------------------------
if($_REQUEST['action'] == 'edit_cat')
{ 
	$id=$_REQUEST['id'];
	$qry_value='select * from '.$wpdb->prefix.'testimonial_category where id='.$id;
	$qry_result1=mysql_query($qry_value);
	while($qry_row=mysql_fetch_array($qry_result1))
	{ //while loop for edit
		entry_form_testimonial_cat($qry_row);
	}
}

//--------------for delete ---------------------------
if($_REQUEST['action'] == 'delete_cat')
{
	$del_id=$_REQUEST['id'];
	delete_testimonial_cat($del_id);
}

?>
</html>