<?php
include_once('myfunction.php');

global $wpdb;
	$t_slide = get_option('tslide_order');
	$qry_display='select * from '.$wpdb->prefix.'testimonial order by id  '.$t_slide;
	$result_display=mysql_query($qry_display);
	?>
	<?php $plugin_url = plugins_url(); ?> 
    <?php
	while($row_display=mysql_fetch_array($result_display))
	{ 
	?>
    <div id='testimonial_display' class='slideshow'>
        <div id="testi_content">
            <img id='quote_open' src='<?php echo $plugin_url; ?>/testimonial/images/testim-quotes-open.png' />
			<?php
			echo "<span id='testi_quote'>".$row_display['quote']."</span>";
			?>
            <img id='quote_close' src='<?php echo $plugin_url; ?>/testimonial/images/testim-quotes-close.png' />
        </div>
        <div id="author_info">
        	<div id="athumb">
            		<img src='<?php echo $plugin_url; ?>/testimonial/upload/<?php echo $row_display["image"]; ?>' />
            </div>
			<div id="authors_detail">        	
				<?php 
		        	if($row_display['author']!='')
		            echo "<div id='testi_author'>".$row_display['author']."</div>";
        		    if($row_display['designation']!='')
		            echo "<div id='testi_author'>".$row_display['designation']."</div>";
					if($row_display['company']!=''){
					if($row_display['company_url']!=''){ 
						echo "<a target='_blank' href='".$row_display['company_url']."'>";
						echo "<div id='testi_author'>".$row_display['company']."</div>";
						echo "</a>"; 
				  	}
					else
						echo "<div id='testi_author'>".$row_display['company']."</div>";							
					} 
				?>
            </div>            
       </div> <!-- author_info end -->
       <div id="rating_display">
            <?php star_rating($row_display['rating']); ?>
       </div>
    </div> <!-- testimonial_display -->
	<?php }
?>
