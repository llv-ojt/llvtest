<?php
include_once('myfunction.php');

$nav_pos = get_option('tshow_nav_pos');
$next_prev_pos = get_option('tshow_next_prev_pos');
?>

<script type="text/javascript" language="javascript">
$(document).ready(function() {
	$('#testi').eq(0).addClass('firsttesti');
});
$(document).ready(function() {
	$('.slideshow_testimonial')
	.after('<div id="testi_nav">')
	.cycle({
	fx: '<?php echo get_option('teffect'); ?>', // choose your transition type, ex: fade, scrollUp, shuffle, etc...
	timeout: <?php echo get_option('ttimeout'); ?>, // milliseconds between slide transitions (0 to disable auto advance)
	speed: <?php echo get_option('tspeed1'); ?>, 
	easing: '<?php echo get_option('teasing1'); ?>',
	pause: 3000,
	pager:  '#testi_nav',
	next:'#next_testimonial',
	prev:'#prev_testimonial'
	});
});
</script>
<?php
	global $wpdb;
    $data = get_option('Testimonial_Widget');

	if(isset($srtcode['cat']))
		$cat_name = $srtcode['cat']; // get the category name from shortcode from shortcode
	elseif(isset($data['cat']))
		$cat_name = $data['cat']; // get the category name from shortcode from widget

		// Get the category id from cat name
    $qry='select id from '.$wpdb->prefix.'testimonial_category where cat_name="'.$cat_name.'"';
	$result=mysql_query($qry);
	
	while($row=mysql_fetch_array($result))
	{
		$cat_id = $row['id'];
	}

	$t_slide = get_option('tslide_order');
	
	if(isset($cat_id)){
	$qry_display='select * from '.$wpdb->prefix.'testimonial where cat_id='.$cat_id.' order by id '.$t_slide;
	} else{
		$qry_display='select * from '.$wpdb->prefix.'testimonial order by id '.$t_slide;		
	}
	
	$result_display=mysql_query($qry_display);
	?>
<?php $plugin_url = plugins_url(); ?> 
<div id='testimonial_widget'>
	<div id="main_header">
          <div id="headerpart">
          <img src='<?php echo $plugin_url; ?>/testimonial/images/icon.png' /><span id="testiheader">Testimonials</span>
          </div>
          <div id="navigation_button">
			  <?php 
			  // for the next/prev top position
  			  if($next_prev_pos == 'Top'){ ?>
			  <div id="next_testimonial" ></div>
		      <div id="prev_testimonial"></div>
		      <?php } ?>
          </div>
     </div>
<div id="main_bottom" >
    <div class='slideshow_testimonial'>
    <?php
	while($row_display=mysql_fetch_array($result_display))
	{ 
	// adjust the words in quote
	/* $counter = get_option('words_count');
	$array1 = explode(' ', $row_display['quote']);
	if (count($array1)<= $counter) {
        $quote_length = $row_display['quote'];
    }
    else {
        array_splice($array1, $counter);
        $quote_length = implode(' ', $array1).' ...';
    } */ 
	?>
    
    <div id='testi'>        
        <div id="testi_content">
            <img id='quote_open' src='<?php echo $plugin_url; ?>/testimonial/images/testim-quotes-open.png' />
            <?php echo '<span id="testi_quote">'.$row_display['quote'].'</span>'; ?>
            <img id='quote_close' src='<?php echo $plugin_url; ?>/testimonial/images/testim-quotes-close.png' />
		</div>
    
        <?php
        echo '<div id="author_info">'; ?>
        <div id="thumb_rating">
		<img id='testi_img' src='<?php echo $plugin_url; ?>/testimonial/upload/<?php echo $row_display["image"]; ?>' />
        </div>
        <div id="authors_detail">
		<?php
            if($row_display['author']!='')
            echo "<div id='testi_author'>".$row_display['author']."</div>";
            if($row_display['designation']!='')
            echo "<div id='testi_author'>".$row_display['designation']."</div>";
			if($row_display['company']!=''){
				if($row_display['company_url']!=''){ 
				echo "<a target='_blank' href='".$row_display['company_url']."'>";
				echo "<div id='testi_author'>".$row_display['company']."</div>";
				echo "</a>"; 
			  	}
				else
					echo "<div id='testi_author'>".$row_display['company']."</div>";							
			} 
            echo "</div>";
        ?>
        </div> <!-- author_info end -->
                    <div id="rating_display">
            <?php star_rating($row_display['rating']); ?>
            </div>
</div>

	<?php }
?>
	</div>
  <?php 
  // for the next/prev bottom position
  	  if($next_prev_pos == 'Bottom'){ ?>
	  <div id="next_testimonial" ></div>
      <div id="prev_testimonial"></div>
  <?php } ?>
  </div>
</div>